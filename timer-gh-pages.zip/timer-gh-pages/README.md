# countdown
Contagem regressiva para monitorar as palestras e lightning talks do FrontInVale.
